<?php
include('inc/topo_login.php');
?>

<body class="hold-transition login-page">
<div class="login-box">
  <div class="login-logo">
    <a href="<?=HOST?>"><b>SERVIÇO DE CLOUD</b><br/>DITEC - SC</a>
  </div>
  <!-- /.login-logo -->
  <div class="card">
    <div class="card-body login-card-body">
      <p class="login-box-msg">Informe seus dados para acessar o sistema.</p>
      <div id="mostra_resultado_login"></div>

      <form action="<?=HOST?>core/login.php" method="post" id="formulario_acesso">
        
        <div class="input-group mb-3">
          <input name="login" type="email" class="form-control login_acesso" placeholder="Email" required>
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-envelope"></span>
            </div>
          </div>
        </div>

        <div class="input-group mb-3">
          <input name="senha" type="password" class="form-control senha_acesso" placeholder="Senha" required>
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-lock"></span>
            </div>
          </div>
        </div>

        <?php /*
        <div class="input-group mb-3">
          <input name="cnpj" type="text" class="form-control cnpj_acesso" placeholder="CNPJ" required>
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-envelope"></span>
            </div>
          </div>
        </div>
        */ ?>

        
        <div class="row">
          <!-- /.col -->
          <div class="col-4">
            <button type="submit" class="btn btn-primary btn-block">Logar</button>
          </div>
          <!-- /.col -->
        </div>

      </form>

    </div>
    <!-- /.login-card-body -->
  </div>
</div>
<!-- /.login-box -->

<?php
include('inc/rodape_login.php');
?>