<?php


require_once('../lib/config.php');

$login  = $_POST['login'];
$senha  = $_POST['senha'];
//$cnpj   = $_POST['cnpj'];

$curl = curl_init();

/*
curl_setopt_array($curl, array(
CURLOPT_URL => HOST_SERVIDOR."/api/Usuarios/login?cnpj=".$cnpj."&login=".$login."&pwd=".$senha."",
CURLOPT_RETURNTRANSFER => true,
CURLOPT_ENCODING => "",
CURLOPT_MAXREDIRS => 10,
CURLOPT_TIMEOUT => 0,
CURLOPT_FOLLOWLOCATION => true,
CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
CURLOPT_CUSTOMREQUEST => "GET",
CURLOPT_HTTPHEADER => array(
    "Content-Type: application/json",
    "Accept: application/json",
  ),
 ));
*/


curl_setopt_array($curl, array(
CURLOPT_URL => HOST_SERVIDOR."/api/UsuarioAdmin/Login?login=".$login."&pwd=".$senha."",
CURLOPT_RETURNTRANSFER => true,
CURLOPT_ENCODING => "",
CURLOPT_MAXREDIRS => 10,
CURLOPT_TIMEOUT => 0,
CURLOPT_FOLLOWLOCATION => true,
CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
CURLOPT_CUSTOMREQUEST => "GET",
CURLOPT_SSL_VERIFYPEER => false,
CURLOPT_SSL_VERIFYHOST => false,
CURLOPT_HTTPHEADER => array(
    "Content-Type: application/json",
    "Accept: application/json",
  ),
  ));


$response = curl_exec($curl);
$data = json_decode($response, true);


if($data['nome']){
  $_SESSION['login_usuario_gerenciador'] = true;
  $_SESSION['nome_usuario'] = $data['nome'];
  $_SESSION['id_usuario'] = $data['idUsuario'];
  $_SESSION['token'] = $data['token'];

  $_SESSION['cliInlcui'] = $data['cliInlcui'];
	$_SESSION['cliEdita'] = $data['cliEdita'];
	$_SESSION['cliDel'] = $data['cliDel'];
	$_SESSION['cliVisu'] = $data['cliVisu'];
	$_SESSION['configEdita'] = $data['configEdita'];
	$_SESSION['camInclui'] = $data['camInclui'];
  $_SESSION['camEdita'] = $data['camEdita'];
  $_SESSION['camDel'] = $data['camDel'];
  $_SESSION['camVisu'] = $data['camVisu'];
  $_SESSION['permissao'] = $data['permissao'];
  $_SESSION['usuInclui'] = $data['usuInclui'];
  $_SESSION['usuEdita'] = $data['usuEdita'];
  $_SESSION['usuDel'] = $data['usuDel'];
  $_SESSION['usuVisu'] = $data['usuVisu'];
  
  echo true;
}else{
  echo false;
}

?>