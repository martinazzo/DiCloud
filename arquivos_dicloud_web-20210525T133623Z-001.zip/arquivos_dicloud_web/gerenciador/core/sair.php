<!DOCTYPE html>
<html>
<head>
	<title>Sair</title>
</head>
<body>
	<?php
	include('../lib/config.php');


	$id_usuario = $_SESSION['id_usuario'];
	
	session_destroy();
	?>

	<script type="text/javascript">
		window.location.href = '<?=HOST?>';
	</script>

</body>
</html>




