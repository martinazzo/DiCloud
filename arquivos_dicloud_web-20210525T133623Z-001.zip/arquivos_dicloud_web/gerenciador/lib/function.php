<?php

function converteAbreviacaoMesParaNumero($abreviacao_mes)
{
	switch ($abreviacao_mes) {
		case 'Jan':
			$numero_mes = '01';
			break;

		case 'Feb':
			$numero_mes = '02';
			break;

		case 'Mar':
			$numero_mes = '03';
			break;

		case 'Apr':
			$numero_mes = '04';
			break;

		case 'May':
			$numero_mes = '05';
			break;

		case 'Jun':
			$numero_mes = '06';
			break;

		case 'Jul':
			$numero_mes = '07';
			break;

		case 'Aug':
			$numero_mes = '08';
			break;

		case 'Sep':
			$numero_mes = '09';
			break;

		case 'Oct':
			$numero_mes = '10';
			break;
		
		case 'Nov':
			$numero_mes = '11';
			break;

		case 'Dec':
			$numero_mes = '12';
			break;

		default:
			$numero_mes = '00';
			break;
	}

	return $numero_mes;
}

function transformaTituloParaUrl($titulo){
	/*Remover Caracteres Especiais*/
	$titulo_sem_caracter_especial  = preg_replace('/[^a-zA-Z0-9_ -]/s','',$titulo);
	
	/*Remover Acentuação*/
	$titulo_sem_acentuacao = preg_replace(array("/(á|à|ã|â|ä)/","/(Á|À|Ã|Â|Ä)/","/(é|è|ê|ë)/","/(É|È|Ê|Ë)/","/(í|ì|î|ï)/","/(Í|Ì|Î|Ï)/","/(ó|ò|õ|ô|ö)/","/(Ó|Ò|Õ|Ô|Ö)/","/(ú|ù|û|ü)/","/(Ú|Ù|Û|Ü)/","/(ñ)/","/(Ñ)/"),explode(" ","a A e E i I o O u U n N"),$titulo_sem_caracter_especial);
	
	/*Substituir espaços por hífen*/
	$titulo_com_hifen = str_replace(' ', '-', $titulo_sem_acentuacao);

	/*Deixar todas as letras em minuscula*/
	$titulo_minusculo = strtolower($titulo_com_hifen);

	return $titulo_minusculo;
}
?>