<?php
session_start();


//Dados Banco de dados
 //error_reporting (E_ALL & ~ E_NOTICE & ~ E_DEPRECATED);

 //ini_set('display_errors',1);

 /*

$banco = 'novosite_cloud';
$usuario = 'novosite_cloud';
$senha = 'Clo*1d@27';
$hostname = 'bdhost0005.servidorwebfacil.com';
$conn = mysql_connect($hostname,$usuario,$senha);

 mysql_select_db($banco) or die( 'Não foi possível conectar ao banco MySQL');

if (!$conn) {
	echo 'Não foi possível conectar ao banco MySQL.'; 
	exit;
}

*/


//define(HOST_CONFIG, 'http://novositesbtsc.cphost0005.servidorwebfacil.com/cloud/plataforma/');
//define(HOST_CONFIG, 'http://189.112.232.171:6066/plataforma/');
define(HOST_CONFIG, 'https://dicloud.ditecsc.com.br/gerenciador/');
//define(HOST_SERVIDOR, 'http://189.112.232.171:5000');
//define(HOST_SERVIDOR, 'https://localhost:5001');
//define(HOST_SERVIDOR, 'http://189.112.232.171:5000');
define(HOST_SERVIDOR, 'https://dicloud.ditecsc.com.br:5001');

//define um parametro para as instancias de bibliotecas, para o caso de modificações na URl
//define(HOST, 'http://189.112.232.171:6066/plataforma/');
define(HOST,'https://dicloud.ditecsc.com.br/gerenciador/');



class Url
{
    private static $url = null;
    private static $baseUrl = null;
 
    public static function getBase()
    {
        if( self::$baseUrl != null )
            return self::$baseUrl;
 
        global $_SERVER;
        $startUrl = strlen( $_SERVER["DOCUMENT_ROOT"] );
        $excludeUrl = substr( $_SERVER["SCRIPT_FILENAME"], $startUrl, -9 );
        if( $excludeUrl[0] == "/" )
            self::$baseUrl = $excludeUrl;
        else
            self::$baseUrl = "/" . $excludeUrl;
        return self::$baseUrl;
    }
 
    public static function getURL( $id )
    {
        // Verifica se a lista de URL já foi preenchida
        if( self::$url == null )
            self::getURLList();
         
        // Valida se existe o ID informado e retorna.
        if( isset( self::$url[ $id ] ) )
            return self::$url[ $id ];
         
        // Caso não exista o ID, retorna nulo
        return null;
    }
     
    private static function getURLList()
    {
        global $_SERVER;
         
        // Primeiro traz todos as pastas abaixo do index.php
        $startUrl = strlen( $_SERVER["DOCUMENT_ROOT"] ) -1;
        $excludeUrl = substr( $_SERVER["SCRIPT_FILENAME"], $startUrl, -10 );
         
        // a variável$request possui toda a string da URL após o domínio.
        $request = $_SERVER['REQUEST_URI'];
         
        // Agora retira toda as pastas abaixo da pasta raiz
        $request = substr( $request, strlen( $excludeUrl ) );
         
        // Explode a URL para pegar retirar tudo após o ?
        $urlTmp = explode("?", $request);
        $request = $urlTmp[ 0 ];
         
        // Explo a URL para pegar cada uma das partes da URL
        $urlExplodida = explode("/", $request);
         
        $retorna = array();
 
        for($a = 0; $a <= count($urlExplodida); $a ++)
        {
            if(isset($urlExplodida[$a]) AND $urlExplodida[$a] != "")
            {
                array_push($retorna, $urlExplodida[$a]);
            }
        }
        self::$url = $retorna;
    }
}

function get_curl_consulta_json($url_consulta,$token,$certificado_ativo){

    if($certificado_ativo){
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $url_consulta,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_HTTPHEADER => array(
                "Content-Type: application/json",
                "Accept: application/json",
                "Authorization: Bearer ".$token.""
                ),
        ));
    }else{
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $url_consulta,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_HTTPHEADER => array(
                "Content-Type: application/json",
                "Accept: application/json",
                "Authorization: Bearer ".$token.""
                ),
        ));
    }
    
    $response = curl_exec($curl);
    $data = json_decode($response, true);

    return $data;
}

function get_curl_consulta_video($video,$id_cliente,$token,$certificado_ativo){

    return HOST.'consulta_video.php?video='.$video.'&id_cliente='.$id_cliente;
}

function get_curl_consulta_imagem($imagem,$id_cliente,$token,$certificado_ativo){

    return HOST.'consulta_imagem.php?imagem='.$imagem.'&id_cliente='.$id_cliente;
}

?>