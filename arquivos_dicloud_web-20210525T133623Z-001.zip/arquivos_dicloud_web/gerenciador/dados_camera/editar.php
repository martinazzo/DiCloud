<?php 
if($_SESSION['camEdita'] != true){
  ?>
  <script>
    window.location.href= '<?=HOST?>permissao_negada'
  </script>
  <?php
  die();
}
?>
<?php

$token      = $_SESSION['token'];

$url = HOST_SERVIDOR."/api/dadoscameras/".$identificacao."";
$consulta_dados_camera = get_curl_consulta_json($url, $token,$certificado_ativo = true);

?>
<!-- Main content -->
    <section class="content">
      <div class="card">
          <div class="card-header">
            <h3 class="card-title">Editar Base de Dados</h3>
          </div>
          <!-- /.card-header -->
            <form role="form" action="<?=HOST?>dados_camera/alterar_conteudo.php" method="post">
                <div class="card-body">

                  <div class="form-group">
                    <label for="Nome">Código Dock</label>
                    <input type="text" name="codigo_dock" class="form-control" placeholder="Informe o Código Dock" value="<?=$consulta_dados_camera['codigoDock']?>">
                  </div>

                  <div class="form-group">
                    <label for="Modelo Câmera">Modelo Câmera</label>
                    <select name="modelo_camera" class="form-control">
                      <option <?php if($consulta_dados_camera['modeloCamera'] == 'seye'){ echo 'selected';}?> value="seye">Seye</option>
                    </select>
                  </div>

                  <div class="form-group">
                    <label for="Nome Câmera">Nome Câmera</label>
                    <input type="text" name="nome_camera" class="form-control" placeholder="Informe o Nome Câmera" value="<?=$consulta_dados_camera['nomeCamera']?>">
                  </div>

                  <div class="form-group">
                    <label for="Número do Agente">Número do Agente</label>
                    <select name="numero_agente" class="form-control">
                      <?php
                        $id_cliente = $consulta_dados_camera['idCliente'];
                        $token      = $_SESSION['token'];
                        
                        $url = HOST_SERVIDOR."/api/agentes/cliente/".$id_cliente."";
                        $lista_agentes = get_curl_consulta_json($url, $token,$certificado_ativo = true); 
                        foreach($lista_agentes as $agente){
                        ?>
                          <option <?php if($agente['idAgente'] == $consulta_dados_camera['idAgente']){ echo "selected";}?> value="<?=$agente['idAgente']?>"><?=$agente['nome']?></option>
                        <?php
                        }
                      ?>
                    </select>
                  </div>

                  <div class="form-group">
                    <label for="Observações">Observações</label>
                    <textarea name="observacoes" class="form-control" placeholder="Informe as Observações"><?=$consulta_dados_camera['observacoes']?></textarea>
                  </div>

                  <div class="form-group">
                    <input type="hidden" name="id_cliente" value="<?=$id_cliente?>">
                    <input type="hidden" name="data_cadastro" value="<?=$consulta_dados_camera['dataCadastro']?>">
                    <input type="hidden" name="id_dados_camera" value="<?=$consulta_dados_camera['idDadosCamera']?>">
                    <input type="submit" class="btn btn-success" value="ENVIAR">
                  </div>
                  
                </div>
                <!-- /.card-body -->
            </form>
        </div>
        <!-- /.card -->     
    </section>
<!-- /.content -->