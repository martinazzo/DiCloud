<?php

include('../lib/config.php');

$codigo_dock 		= $_POST['codigo_dock'];
$modelo_camera 		= $_POST['modelo_camera'];
$nome_camera 		= $_POST['nome_camera'];
$id_agente 			= (int)$_POST['numero_agente'];
$observacoes 		= $_POST['observacoes'];
$id_cliente 		= (int)$_POST['id_cliente'];


$token      = $_SESSION['token'];

$postRequest = array(
    'codigoDock' 	=> $codigo_dock,
	'modeloCamera' 	=> $modelo_camera,
	'nomeCamera' 	=> $nome_camera,
	'idAgente' 		=> $id_agente,
	'observacoes' 	=> $observacoes,
	'idCliente' 	=> $id_cliente
);

$jsonRequest = json_encode($postRequest);

$curl = curl_init();

curl_setopt_array($curl, array(
CURLOPT_URL => HOST_SERVIDOR."/api/dadoscameras/",
CURLOPT_RETURNTRANSFER => true,
CURLOPT_POSTFIELDS => $jsonRequest,
CURLOPT_ENCODING => "",
CURLOPT_MAXREDIRS => 10,
CURLOPT_TIMEOUT => 0,
CURLOPT_FOLLOWLOCATION => true,
CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
CURLOPT_CUSTOMREQUEST => "POST",
CURLOPT_SSL_VERIFYPEER => false,
CURLOPT_SSL_VERIFYHOST => false,
CURLOPT_HTTPHEADER => array(
	"Content-Type: application/json",
	"Accept: application/json",
	"Authorization: Bearer ".$token.""
),
));

$response = curl_exec($curl);
$dadoscamera_cadastrado = json_decode($response, true);

?>
<script type="text/javascript">
	window.location.href = '<?=HOST_CONFIG?>dados_camera/lista/<?=$id_cliente?>';
</script>

