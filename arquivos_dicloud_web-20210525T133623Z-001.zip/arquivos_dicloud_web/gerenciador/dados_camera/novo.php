<?php 
if($_SESSION['camInclui'] != true){
  ?>
  <script>
    window.location.href= '<?=HOST?>permissao_negada'
  </script>
  <?php
  die();
}
?>
<?php
$id_cliente = $identificacao;
?>
<!-- Main content -->
    <section class="content">
      <div class="card">
          <div class="card-header">
            <h3 class="card-title">Nova Câmera</h3>
          </div>
          <!-- /.card-header -->
            <form role="form" action="<?=HOST?>dados_camera/inserir_novo.php" method="post">
                <div class="card-body">

                  <div class="form-group">
                    <label for="Código Dock">Código Dock</label>
                    <input type="text" name="codigo_dock" class="form-control" placeholder="Informe o Código Dock">
                  </div>

                  <div class="form-group">
                    <label for="Modelo Câmera">Modelo Câmera</label>
                    <select name="modelo_camera" class="form-control">
                      <option value="seye">Seye</option>
                    </select>
                  </div>

                  <div class="form-group">
                    <label for="Nome da Câmera">Nome da Câmera</label>
                    <input type="text" name="nome_camera" class="form-control" placeholder="Informe o Nome da Câmera">
                  </div>

                  <div class="form-group">
                    <label for="Número do Agente">Número do Agente</label>
                    <select name="numero_agente" class="form-control">
                      <?php
                        $token      = $_SESSION['token'];
                        $url = HOST_SERVIDOR."/api/agentes/cliente/".$id_cliente."";
                        $lista_agentes = get_curl_consulta_json($url,$token,$certificado_ativo = true); 
                        foreach($lista_agentes as $agente){
                        ?>
                          <option value="<?=$agente['idAgente']?>"><?=$agente['nome']?></option>
                        <?php
                        }
                      ?>
                    </select>
                  </div>

                  <div class="form-group">
                    <label for="Observações">Observações</label>
                    <textarea name="observacoes" class="form-control" placeholder="Informe as Observações"></textarea>
                  </div>

                  <div class="form-group">
                    <input type="hidden" name="id_cliente" value="<?=$id_cliente?>">
                    <input type="submit" class="btn btn-success" value="ENVIAR">
                  </div>
                  
                </div>
                <!-- /.card-body -->
            </form>
        </div>
        <!-- /.card -->     
    </section>
<!-- /.content -->