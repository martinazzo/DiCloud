<?php 
if($_SESSION['camVisu'] != true){
  ?>
  <script>
    window.location.href= '<?=HOST?>permissao_negada'
  </script>
  <?php
  die();
}
?>
<?php
$id_cliente = $identificacao;
?>

<!-- Main content -->
    <section class="content">
      <div class="card">
          <div class="card-header">
            <h3 class="card-title">Lista das Câmeras</h3>
          </div>
          <!-- /.card-header -->
          <div class="card-body">
            <table id="example1" class="table table-bordered table-striped">
              <thead>
              <tr>
                <th>Código Dock</th>
                <th>Modelo Câmera</th>
                <th>Nome Câmera</th>
                <th>Agente</th>
                <th>Ações</th>
              </tr>
              </thead>
              <tbody>
              <?php


              $id_cliente = $identificacao;
              $token      = $_SESSION['token'];

              $url = HOST_SERVIDOR."/api/dadoscameras/cliente/".$id_cliente."";
              $lista_cameras = get_curl_consulta_json($url, $token,$certificado_ativo = true);

              foreach($lista_cameras as $consulta_dados_camera){
              ?>
                <tr>
                  <td><?=$consulta_dados_camera['codigoDock']?></td>
                  <td><?=$consulta_dados_camera['modeloCamera']?></td>
                  <td><?=$consulta_dados_camera['nomeCamera']?></td>
                  <td>
                    <?php
                      $token      = $_SESSION['token'];
        
                      $url = HOST_SERVIDOR."/api/agentes/".$consulta_dados_camera['idAgente']."";
                      $consulta_agente = get_curl_consulta_json($url, $token,$certificado_ativo = true); 
                      echo $consulta_agente['nome'];
                    ?>
                  </td>
                  <td>
                    <a onclick="return confirm('Deseja realmente deletar este item?')" href="<?=HOST?>dados_camera/excluir_dados_camera.php?id_dados_camera=<?=$consulta_dados_camera['idDadosCamera']?>&id_cliente=<?=$id_cliente?>"><i class="fas fa-trash-alt"></i></a>
                    <a href="<?=HOST?>dados_camera/editar/<?=$consulta_dados_camera['idDadosCamera']?>"><i class="far fa-edit"></i></a>
                  </td>
                </tr>
              <?php
              }
              ?>
              </tbody>
              <tfoot>
              <tr>
                <th>Código Dock</th>
                <th>Modelo Câmera</th>
                <th>Nome Câmera</th>
                <th>Agente</th>
                <th>Ações</th>
              </tr>
              </tfoot>
            </table>
          </div>
          <!-- /.card-body -->
        </div>
        <!-- /.card -->     
    </section>
<!-- /.content -->