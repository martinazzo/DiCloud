<?php

//referencia para a conexão com o banco de dados e a função que pega a URL com mais facilidade
require_once('lib/config.php');


//pega o item da URL
$modulo = Url::getURL( 0 );
$pagina = Url::getURL( 1 );
$identificacao = Url::getURL( 2 );

//verifica se o usuário está logado, para redirecionar para a tela de login
if($_SESSION['login_usuario_gerenciador'] == true){

	//nesse primeiro caso se a pessoa está logado e está na pagina de login será redirecionado para o index
	if( $modulo == 'login' ){
	    $modulo = "index";
	}
	//se o modulo estiver nulo será redirecionado para a index
	else if($modulo == null){
		$modulo = "index";
	} if( file_exists( "pages/" . $modulo . ".php" ) ){
    	$modulo = $modulo;
	} else
	{
	    $modulo = "index";
	}

	//chama o arquivo na pasta pages
	require "pages/" . $modulo . ".php";

// nesse caso do else não existe a sessão login
}else{

	//se não está na pagina de login será redirecionado para a pagina de login
	if($modulo != 'login')
	{ ?>
		<script type="text/javascript">
			window.location.href = '<?=HOST?>login';
		</script>
	<?php
	}else{
		//se estiver na pagina de login abrirá o arquivo de login
		require "pages/" . $modulo . ".php";
	}
}

?>